package vcmsa.ci.luumealplan

import android.os.Bundle
import android.widget.EditText
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val edtInput = findViewById<EditText>(R.id.edtInput)
        val txtResults = findViewById<TextView>(R.id.txtResults)
        val btnOptions = findViewById<Button>(R.id.btnOptions)
        val btnRemove = findViewById<Button>(R.id.btnRemove)

    btnOptions.setOnClickListener {
        val time = edtInput.text.toString()
        val meal:String

        if(time.lowercase() == "morning"){
           meal = "kellogs cornflakes/weetbix/croissant with coffee"
        }

        else if(time.lowercase() == "mid morning"){
            meal = "muesli with yogurt/eggs benedict with toasted bread/avo,bacon with a greek salad"
        }

        else if(time.lowercase() == "afternoon"){
            meal = "vegan bunnychow/oil free chips with two frankfurters/dagwood toasted sandwich"
        }

        else if(time.lowercase() == "dinner"){
            meal = "ribs,t-bone steak with a greek salad/penne pasta with a oxtail stew"
        }

        else{
            meal = "Invalid Input"
        }

        txtResults.text = meal
    }

    btnRemove.setOnClickListener(){

        edtInput.setText("")
        txtResults.setText("")
    }














        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.btnSuggest)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}